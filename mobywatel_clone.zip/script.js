function saveData() {
    const fullname = document.getElementById("fullname").value;
    const pesel = document.getElementById("pesel").value;
    localStorage.setItem("fullname", fullname);
    localStorage.setItem("pesel", pesel);
    document.getElementById("savedInfo").innerText = "Dane zapisane lokalnie!";
}

window.onload = () => {
    const fullname = localStorage.getItem("fullname");
    const pesel = localStorage.getItem("pesel");
    if (fullname) document.getElementById("fullname").value = fullname;
    if (pesel) document.getElementById("pesel").value = pesel;
}